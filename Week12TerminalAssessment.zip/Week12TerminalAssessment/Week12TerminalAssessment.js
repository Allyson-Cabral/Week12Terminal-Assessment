const form = document.getElementById("contactForm");
const emailInput = document.getElementById("email");

form.addEventListener("submit", function(event){

    event.preventDefault();

    const emailValue = emailInput.value;

    if(!emailValue.includes("@")){

        emailInput.classList.add("is-invalid");
        emailInput.classList.remove("is-valid");

    } else {

        emailInput.classList.remove("is-invalid");
        emailInput.classList.add("is-valid");

    }

    if(form.checkValidity() && emailValue.includes("@")){

        alert("Message Sent Successfully!");

        form.reset();

        emailInput.classList.remove("is-valid");

    }

});